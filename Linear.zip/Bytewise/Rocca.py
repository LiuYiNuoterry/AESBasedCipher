from coptpy import *
import time

env = Envr()
model = env.createModel("Rocca_Sbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

alpha0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpha1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
lam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
lam1 = model.addVars(list(range(16)), vtype = COPT.BINARY)

a = model.addVars(list(range(16)), vtype = COPT.BINARY)
b = model.addVars(list(range(16)), vtype = COPT.BINARY)
c = model.addVars(list(range(16)), vtype = COPT.BINARY)
d = model.addVars(list(range(16)), vtype = COPT.BINARY)
e = model.addVars(list(range(16)), vtype = COPT.BINARY)
f = model.addVars(list(range(16)), vtype = COPT.BINARY)
g = model.addVars(list(range(16)), vtype = COPT.BINARY)
h = model.addVars(list(range(16)), vtype = COPT.BINARY)
l = model.addVars(list(range(16)), vtype = COPT.BINARY)
m = model.addVars(list(range(16)), vtype = COPT.BINARY)
n = model.addVars(list(range(16)), vtype = COPT.BINARY)

glam0 = model.addVars(list(range(16)), vtype = COPT.BINARY) 
bggamma1lam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
adenlam1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
ehlbeta1gamma0 =model.addVars(list(range(16)), vtype = COPT.BINARY)
ehgamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
cmbeta0lam1 =model.addVars(list(range(16)), vtype = COPT.BINARY) 
mbeta0 =model.addVars(list(range(16)), vtype = COPT.BINARY)
fggamma1 =model.addVars(list(range(16)), vtype = COPT.BINARY) 
afggamma1 =model.addVars(list(range(16)), vtype = COPT.BINARY) 
dlam1 =model.addVars(list(range(16)), vtype = COPT.BINARY) 
bcfgamma1lam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)

eh = model.addVars(list(range(16)), vtype = COPT.BINARY) 
fg = model.addVars(list(range(16)), vtype = COPT.BINARY) 
bglam0 = model.addVars(list(range(16)), vtype = COPT.BINARY) 
bflam0 = model.addVars(list(range(16)), vtype = COPT.BINARY) 
bggamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY) 
bgamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY) 
ggamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
fgamma1lam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)

lbeta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
bc = model.addVars(list(range(16)), vtype = COPT.BINARY)
en = model.addVars(list(range(16)), vtype = COPT.BINARY)
denlam1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
clam1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
fgamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
flam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)

ind   = model.addVars(list(range(72)), vtype = COPT.BINARY)

X1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X4 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X5 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X6 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X7 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X8 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X9 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X10 = model.addVars(list(range(16)), vtype = COPT.BINARY)
X11 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Z1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z4 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z5 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z6 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z7 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z8 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z9 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z10 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z11 = model.addVars(list(range(4)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])
    
def xor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def fun(inp0, inp1, diff, X, Z):
    for i in range(16): 
        xor(inp0[i], inp1[i], X[i])
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, X[4*i] + X[(4*i+5)%16] + X[(4*i+10)%16] + X[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, X[4*i] + X[(4*i+5)%16] + X[(4*i+10)%16] + X[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)

def modeling():
    start_time = time.perf_counter()
    for i in range(16):
        xor(g[i], lam0[i], glam0[i]) # 1
        xor(b[i], gamma1[i], bgamma1[i]) # 13
        xor(b[i], c[i], bc[i])
        xor(f[i], gamma1[i], fgamma1[i])
        xor(beta0[i], m[i], mbeta0[i]) # 7
        xor(c[i], lam1[i], clam1[i])
        xor(e[i], h[i], eh[i]) # 15
        xor(l[i], beta1[i], lbeta1[i]) # 12
        xor(g[i], gamma1[i], ggamma1[i]) # 14
        xor(f[i], g[i], fg[i]) # 16
        xor(d[i], lam1[i], dlam1[i]) # 9
        xor(e[i], n[i], en[i])
        xor(f[i], lam0[i], flam0[i])
        
        xor(b[i], glam0[i], bglam0[i]) # 19
        xor(bgamma1[i], g[i], bggamma1[i]) # 17
        xor(ggamma1[i], b[i], bggamma1[i]) # 17
        xor(eh[i], gamma0[i], ehgamma0[i]) # 5
        xor(f[i], ggamma1[i], fggamma1[i]) # 9
        xor(fg[i], gamma1[i], fggamma1[i]) # 9
        xor(g[i], fgamma1[i], fggamma1[i]) # 9
        xor(b[i], flam0[i], bflam0[i]) # 20
        xor(fgamma1[i], lam0[i], fgamma1lam0[i]) # 18
        xor(gamma1[i], flam0[i], fgamma1lam0[i]) # 18
        
        xor(bgamma1[i], glam0[i], bggamma1lam0[i]) # 2
        xor(bggamma1[i], lam0[i], bggamma1lam0[i]) # 2
        xor(gamma1[i], bglam0[i], bggamma1lam0[i]) # 2
        xor(mbeta0[i], clam1[i], cmbeta0lam1[i]) # 6
        xor(a[i], fggamma1[i], afggamma1[i]) # 8
        xor(dlam1[i], en[i], denlam1[i]) # 11
        
        xor(bc[i], fgamma1lam0[i], bcfgamma1lam0[i]) # 10
        xor(ehgamma0[i], lbeta1[i], ehlbeta1gamma0[i]) # 4 
        xor(a[i], denlam1[i], adenlam1[i]) # 3
        
        model.addConstr(d[i] == cmbeta0lam1[i])
        model.addConstr(f[i] == h[i])
        model.addConstr(g[i] == m[i])

        # S6
        model.addConstr(denlam1[i] == lbeta1[i])

    AESRound(a, alpha1, 0)
    AESRound(b, beta0, 4)
    AESRound(c, beta1, 8)
    AESRound(d, gamma0, 12)
    AESRound(e, gamma1, 16)
    AESRound(f, lam0, 20)
    AESRound(g, lam1, 24)
    AESRound(h, lam0, 28)
    AESRound(l, glam0, 32)
    AESRound(m, lam1, 36)
    AESRound(n, f, 40)
    AESRound(adenlam1, bggamma1lam0, 44)
    AESRound(ehlbeta1gamma0, alpha0, 48)
    AESRound(alpha1, ehgamma0, 52)
    AESRound(cmbeta0lam1, gamma0, 56)
    AESRound(afggamma1, mbeta0, 60)
    AESRound(alpha0, fggamma1, 64)
    AESRound(bcfgamma1lam0, dlam1, 68)
        
    # outer masks
    t = 0
    for i in range(16):
        t = t + alpha0[i] + alpha1[i] + beta0[i] + beta1[i] + gamma0[i] + gamma1[i] + lam0[i] + lam1[i]
    model.addConstr(t >= 1)

    # break the gap
    fun(b, afggamma1, m,  X1, Z1)
    fun(d, alpha1, eh, X2, Z2)
    fun(e, adenlam1, bglam0, X3, Z3)
    fun(e, alpha0, fg, X4, Z4)
    fun(alpha0, adenlam1, bflam0, X5, Z5)
    fun(f, l, g, X6, Z6)
    fun(f, adenlam1, bggamma1, X7, Z7)
    fun(l, adenlam1, bgamma1, X8, Z8)
    fun(g, bcfgamma1lam0, d, X9, Z9)
    fun(n, alpha0, ggamma1, X10, Z10)
    fun(l, alpha0, fgamma1lam0, X11, Z11)

    #Objective Function
    obj = 0 
    for r in range(16):
        obj = obj +  a[r] + b[r] + c[r] + d[r] + e[r] + f[r] + g[r] + h[r] + l[r] + m[r] + n[r] + adenlam1[r] + ehlbeta1gamma0[r] + alpha1[r] + cmbeta0lam1[r] + afggamma1[r] + alpha0[r] + bcfgamma1lam0[r]

    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()
    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")
    
    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))

    
 
modeling()    
