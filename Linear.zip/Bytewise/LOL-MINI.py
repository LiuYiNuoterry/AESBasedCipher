from coptpy import *
import time

env = Envr()
model = env.createModel("LOLALinearSbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

alpha = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta  = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma = model.addVars(list(range(16)), vtype = COPT.BINARY)
lam   = model.addVars(list(range(16)), vtype = COPT.BINARY)
a     = model.addVars(list(range(16)), vtype = COPT.BINARY)
b     = model.addVars(list(range(16)), vtype = COPT.BINARY)
c     = model.addVars(list(range(16)), vtype = COPT.BINARY)
d     = model.addVars(list(range(16)), vtype = COPT.BINARY)
e     = model.addVars(list(range(16)), vtype = COPT.BINARY)
f     = model.addVars(list(range(16)), vtype = COPT.BINARY)
g     = model.addVars(list(range(16)), vtype = COPT.BINARY)
h     = model.addVars(list(range(16)), vtype = COPT.BINARY)
ad    = model.addVars(list(range(16)), vtype = COPT.BINARY)
be    = model.addVars(list(range(16)), vtype = COPT.BINARY)
adf   = model.addVars(list(range(16)), vtype = COPT.BINARY)
calpha = model.addVars(list(range(16)), vtype = COPT.BINARY)
clam = model.addVars(list(range(16)), vtype = COPT.BINARY)
gammag = model.addVars(list(range(16)), vtype = COPT.BINARY)
betah = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpham = model.addVars(list(range(16)), vtype = COPT.BINARY)

ind   = model.addVars(list(range(48)), vtype = COPT.BINARY)

A1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A4 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Y1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y4 = model.addVars(list(range(4)), vtype = COPT.BINARY)

Z1 = model.addVars(list(range(8)), vtype = COPT.BINARY)
Z2 = model.addVars(list(range(8)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])

def bitxor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)
    model.addConstr(out <= 2 - inp1 - inp2)

def xor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def fun(inp0, inp1, diff, A, Z):
    for i in range(16):
        xor(inp0[i], inp1[i], A[i])
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)
        

def modeling():
    start_time = time.perf_counter()
    for i in range(16):
        xor(a[i],  d[i], ad[i])
        xor(b[i],  e[i], be[i])
        xor(beta[i], h[i], betah[i])
        xor(c[i], alpha[i], calpha[i])
        xor(c[i], lam[i], clam[i])
        xor(gamma[i], g[i], gammag[i])
        xor(ad[i], f[i], adf[i])

    AESRound(g, lam, 0)
    AESRound(h, gammag, 4)
    AESRound(alpha, betah, 8)
    AESRound(a, lam, 12)
    AESRound(b, a, 16)
    AESRound(c, b, 20)
    AESRound(d, gamma, 24)
    AESRound(e, ad, 28)
    AESRound(c, be, 32)
    AESRound(f, calpha, 36)
    AESRound(be, f, 40)
    AESRound(adf, beta, 44)
    
    t = 0
    for r in range(0,16):
        t = t + alpha[r] + beta[r] + gamma[r] + lam[r]
    model.addConstr(t >= 1)

    # break the gap
    for i in range(16):
        model.addConstr(a[i] == g[i])
    fun(b, e, d,  A1, Y1)
    fun(adf, alpha, h, A2, Y2)
    fun(d, h, g, A3, Y3)
    fun(c, c, e, A4, Y4)

    #Objective Function
    obj = 0 
    for r in range(16):
        obj = obj + g[r] + h[r] + alpha[r] + a[r] + b[r] + c[r] + d[r] + e[r] + f[r] + adf[r] + c[r] + be[r]
        
    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()
    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")

    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))

modeling()
